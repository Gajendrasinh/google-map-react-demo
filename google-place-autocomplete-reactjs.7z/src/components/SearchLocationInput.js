import React from "react";
import { useFormik } from "formik";
import { useSelector, useDispatch } from 'react-redux';
import { searchAction } from './../Store/actions/searchAction';

import Autocomplete from "react-google-autocomplete";

export default function SearchInput() {

    const dispatch = useDispatch();

    const formik = useFormik({
        initialValues: {
            countryAnother: "",
        },
        onSubmit: (values) => {
            alert(JSON.stringify(values, null, 2));
        },
    });



    return (
        <div>
            <form
                onSubmit={formik.handleSubmit}
                style={{ display: "flex", flexDirection: "row" }}
            >
                <Autocomplete
                    style={{ width: "250px" }}
                    id="countryAnother"
                    placeholder="Search here..."
                    value={formik.values.countryAnother}
                    apiKey="AIzaSyDQRjgcwgd917cq-ufrPawhlTV8yyr5LgU"
                    onPlaceSelected={(place) => {
                        console.log(place)

                        dispatch(searchAction({
                            type: 'INCREMENT',
                            action: {
                                lat: place,
                                lng: place
                            }
                        }))
                        formik.setFieldValue("countryAnother", place.formatted_address)
                    }}
                    onChange={formik.handleChange}
                />
            </form>
        </div>
    );
}
